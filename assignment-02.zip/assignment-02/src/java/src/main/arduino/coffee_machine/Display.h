#ifndef __DISPLAY__
#define __DISPLAY__

class Display {

  public:
    Display();
    void setText(String msg);

};

#endif
